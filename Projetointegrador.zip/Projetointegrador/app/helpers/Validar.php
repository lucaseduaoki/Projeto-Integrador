<?php

namespace app\helpers;

class Validar{

    private array $erros = [];

    public function obrigatorio(string $campo, mixed $valor, ?string $mensagem = null){
        if (empty($valor) && $valor !== '0'){
            $this->erros[$campo] = $mensagem ?? "O campo $campo é obrigatório.";
        }

        return $this;
    }

}